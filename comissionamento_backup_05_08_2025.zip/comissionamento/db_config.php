<?php
// Configuração da conexão com o banco de dados
return [
    'host' => '127.0.0.1',
    'user' => 'root',
    'password' => '', // Substitua pela senha do seu banco de dados
    'dbname' => 'comissionamento',
];
?>
